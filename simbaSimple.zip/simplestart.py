import pandas as pd
import requests
import io
import time
import logging
from simbaSimple.kiteUtility import KiteUtility
from simbaSimple.algoUtility import AlgoUtile

ku = KiteUtility('nCqy1hsJaczMQV3pFRyd8jAa9cdqwmOM')
#ku.getNwriteNifty50InstrumentToken()
it_df = ku.getInstrumentTokenDF()
d={}
for instrument in list(it_df["instrument_token"]):
    ohlc_df=None
    ohlc_df=ku.getHistoricalData(instrument)
    time.sleep(.5)
    symbol = ku.getSymbolFromInstrument(instrument)
    d[symbol]=AlgoUtile.HA(ohlc_df)

for k in d.keys():
    HA=d[k]
    if (HA["Buy"].tail(1).values[0]==True):
        print(k)
        d_ltp = ku.kite.ltp(["NSE:" + k])
    pass


#HA = AlgoUtile.HA(ohlc_df)






pass


