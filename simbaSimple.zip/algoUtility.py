from collections import namedtuple
import pandas as pd
import numpy as np

class AlgoUtile:
    def HA(df):
        df['HA_Close'] = (df['open'] + df['high'] + df['low' ] +df['close'] ) /4
        hkOpen, hkclose = [], []
        nt = namedtuple('nt', ['open', 'close'])
        previous_row = nt(df.ix[0, 'open'], df.ix[0, 'close'])
        i = 0
        for row in df.itertuples():
            ha_open = (previous_row.open + previous_row.close) / 2
            hkOpen.append(previous_row[0])
            hkclose.append(previous_row[1])
            df.ix[i, 'HA_Open'] = ha_open
            previous_row = nt(ha_open, row.close)
            i += 1

        df['HA_High'] = df[['HA_Open', 'HA_Close', 'high']].max(axis=1)
        df['HA_Low'] = df[['HA_Open', 'HA_Close', 'low']].min(axis=1)
        df['HA_OldOPEN'] = pd.Series(np.array(hkOpen), index=df.index)
        df['HA_OldCLOSE'] = pd.Series(np.array(hkclose), index=df.index)
        return AlgoUtile.HA_buysell(df)


    def HA_buysell(df):
        bullishCandle = (df['HA_Close'] > df['HA_Open']) & (df['HA_Low']  == df['HA_Open'])
        bearishCandle = (df['HA_Close'] < df['HA_Open']) & (df['HA_High'] == df['HA_Open'])
        numCandle = bullishCandle.values
        numbearishCandle = bearishCandle.values
        buyIndex = []
        sellIndex = []
        for val in range(0, len(numCandle) - 1):
            # buy
            if val == 0:
                buyIndex.append(False)
            if numCandle[val]:# and numCandle[val + 1]:
                if buyIndex[val] != True:
                    buyIndex.append(True)
                else:
                    buyIndex.append(False)
            else:
                buyIndex.append(False)
            # sell
            if val == 0:
                sellIndex.append(False)
            if numbearishCandle[val]:# and numbearishCandle[val + 1]:
                if sellIndex[val] != True:
                    sellIndex.append(True)
                else:
                    sellIndex.append(False)
            else:
                sellIndex.append(False)

        if buyIndex == []:
            buyIndex = [False]
        df["Buy"] = buyIndex
        if sellIndex == []:
            sellIndex = [False]
        df["ShortSell"] = sellIndex
        return df



