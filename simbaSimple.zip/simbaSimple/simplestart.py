import pandas as pd
import requests
import io
import time
import datetime
import logging
from simbaSimple.kiteUtility import KiteUtility
from simbaSimple.algoUtility import AlgoUtile
from datetime import date
import talib




def startTrade(ku,it_df):
    print("started simba successfully!")
    while(1):
        d={}
        for instrument in list(it_df["instrument_token"]):
            ohlc_df=None
            ohlc_df=ku.getHistoricalData(instrument)
            time.sleep(1)
            symbol = ku.getSymbolFromInstrument(instrument)

            d[symbol]=AlgoUtile.stochrsi(AlgoUtile.HA(ohlc_df))

        for k in d.keys():
            HA=d[k]
            if (HA["Bull"].tail(1).values[0]==True):
                dif = HA["HA_Close"].tail(1).values[0] - HA["HA_Open"].tail(1).values[0]
                if (dif >= 1):
                    print(k)
                    time.sleep(1)
                    d_ltp = ku.kite.ltp(["NSE:" + k])
                    time.sleep(1)
                    ltp = d_ltp[list(d_ltp.keys())[0]]['last_price']
                    #ku.placeOrderBuy(k,ltp)

            if (HA["Bear"].tail(1).values[0]==True):
                dif = HA["HA_Open"].tail(1).values[0] - HA["HA_Close"].tail(1).values[0]
                if(dif >= 1):
                    print(k)
                    time.sleep(1)
                    d_ltp = ku.kite.ltp(["NSE:" + k])
                    time.sleep(1)
                    ltp = d_ltp[list(d_ltp.keys())[0]]['last_price']
                    #ku.placeOrderSell(k,ltp)
            pass
        break
        print("waiting")
        time.sleep(900)



        dt = datetime.datetime.now()
        if (dt.hour == 3 and dt.minute >= 16):
            break


while (1):
    break
    dt = datetime.datetime.now()
    if (dt.hour == 9 and dt.minute == 30  and dt.second == 1):
        break

print("started")
token=''
with open("token.txt", "r")as f:
    token=f.read()
print(token)
ku = KiteUtility(token)
# ku.getNwriteNifty50InstrumentToken()
it_df = ku.getInstrumentTokenDF()
startTrade(ku, it_df)


pass


