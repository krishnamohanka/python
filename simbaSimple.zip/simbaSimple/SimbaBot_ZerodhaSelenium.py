import socket
from selenium import webdriver
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.common.by import By
from selenium.common.exceptions import TimeoutException
from time import sleep
import datetime
from kiteconnect import KiteConnect


class ZerodhaSelenium:
    def __init__(self, driverpath, loginurl, apikey, apisecret):
        self.driver = driverpath
        self.loginurl = loginurl
        self.apikey = apikey
        self.apisecret = apisecret
        self.token = ""
        # self.fulltime = []
        # self.fullprice = []
        self.startScrape()

    def startScrape(self):
        options = Options()
        options.add_argument('--headless')
        options.add_argument('--no-sandbox')
        options.add_argument('--disable-gpu')

        driver = webdriver.Chrome(self.driver, chrome_options=options)

        # driver = webdriver.Chrome(self.driver, chrome_options=options)

        driver.get(self.loginurl)
        sleep(5)
        usrInput=driver.find_elements_by_tag_name("input")[0]
        pwdInput=driver.find_elements_by_tag_name("input")[1]

        usrInput.send_keys("YK8879")
        sleep(1)
        pwdInput.send_keys("jaggu123")
        driver.find_element_by_tag_name("button").click()
        delay = 15 #seconds
        try:
            myElem = WebDriverWait(driver, delay).until(EC.text_to_be_present_in_element((By.TAG_NAME, 'h2'),'Security questions'))
            print ("Page is ready!")
        except TimeoutException:
            print ("Loading took too much time!")

        qdict = {"car": "1234", "vegetable": "1234", "birthplace": "1234", "email": "1234"}

        q1=driver.find_elements_by_tag_name("label")[0]
        q2=driver.find_elements_by_tag_name("label")[1]

        a1 = ""
        a2 = ""
        for k in qdict.keys():
            if str(q1.text).find(k) > 1:
                a1 = qdict[k]
                break
            else:
                a1 = "1234"

        for k in qdict.keys():
            if str(q2.text).find(k) > 1:
                a2 = qdict[k]
                break
            else:
                a2 = "1234"

        driver.find_elements_by_tag_name("input")[0].send_keys(a1)
        driver.find_elements_by_tag_name("input")[1].send_keys(a2)
        sleep(1)
        driver.find_element_by_tag_name("button").click()

        try:
            myElem = WebDriverWait(driver, delay).until(EC.url_contains('127'))
            requesttoken = str(driver.current_url).split('request_token=')[1].split('&')[0]
            self.token = self.kiteConnectionsetup(requesttoken)
            # print (self.requesttoken)
            return self.token
        except TimeoutException:
            print ("Loading took too much time!")

    def kiteConnectionsetup(self, reguestToken):
        if 'BNDA' == socket.gethostname()[:4]:
            proxies = {
               
            }
        else:
            proxies = {

            }
        kite = KiteConnect(api_key=self.apikey, proxies=proxies)
        if 'BNDA' == socket.gethostname()[:4]:
            data = kite.generate_session(reguestToken, self.apisecret)  # works at airbus
        else:
            data = kite.generate_session(reguestToken, self.apisecret)  # works at home
            #kite.set_access_token(data["access_token"])
            print (data)
            with open("token.txt", "w")as f:
                f.write(data['access_token'])
        return data


if __name__ == '__main__':
    loginurl = "https://kite.trade/connect/login?api_key=yw8yelu5bpfel8ib&v=3"
    filename = r"C:\Users\krsna\PycharmProjects\Flaskweb\SimbaBot-master\driver\chromedriver.exe"
    print("waiting for token")
    while (1):
        break
        dt = datetime.datetime.now()
        if (dt.hour == 8 and dt.minute == 45):
            print("token triggered")
            break

    k = ZerodhaSelenium(filename, loginurl,'yw8yelu5bpfel8ib','vaddqe1qb3lzorst3uolc1ptdo0l2cku')



