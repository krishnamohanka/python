import pandas as pd
import requests
import io
import time
import datetime
import logging
from simbaSimple.kiteUtility import KiteUtility
from simbaSimple.algoUtility import AlgoUtile
from datetime import date
import talib


def startTrade(ku, it_df):
    print("started simba successfully!")
    first=True
    while (1):
        d = {}
        for instrument in list(it_df["instrument_token"]):
            if(instrument == 2714625):
                ohlc_df = None
                ohlc_df = ku.getHistoricalData(instrument)
                time.sleep(1)
                symbol = ku.getSymbolFromInstrument(instrument)
                d[symbol] = AlgoUtile.EMA(ohlc_df)
                break

        for k in d.keys():
            HA = d[k]
            if (HA["EMABuy"].tail(1).values[0] == False):
                # dif = HA["HA_Close"].tail(1).values[0] - HA["HA_Open"].tail(1).values[0]
                # if (dif >= 1):
                print(k)
                time.sleep(1)
                #d_ltp = ku.kite.ltp(["NSE:" + k])
                instrument = ku.getInstrumentFromSymabol(k)
                buyprice, buyqty,sellprice,selqty = ku.get_price(instrument)
                time.sleep(1)
                #ltp = d_ltp[list(d_ltp.keys())[0]]['last_price']

                ku.placeOrderBuy(k, buyprice, 10)
                if (not first):
                    ku.placeOrderBuy(k, buyprice + .10, 10)

                if first:
                    first = False

            if (HA["EMASell"].tail(1).values[0] == True):
                # dif = HA["HA_Close"].tail(1).values[0] - HA["HA_Open"].tail(1).values[0]
                # if (dif >= 1):
                print(k)
                time.sleep(1)
                #d_ltp = ku.kite.ltp(["NSE:" + k])
                instrument = ku.getInstrumentFromSymabol(k)
                sellprice,selqty = ku.get_price(instrument)
                time.sleep(1)
                #ltp = d_ltp[list(d_ltp.keys())[0]]['last_price']


                ku.placeOrderSell(k, sellprice, 10)
                time.sleep(1)
                if (not first):
                    ku.placeOrderSell(k, sellprice - .10, 10)

                if first:
                    first = False
            pass

        print("waiting")
        time.sleep(300)

        dt = datetime.datetime.now()
        if (dt.hour == 15 and dt.minute >= 30):
            break

print("waiting to start ")
while (1):
    break
    dt = datetime.datetime.now()
    if (dt.hour == 11 and dt.minute == 45 and dt.second == 3):
        break

print("started")
token = ''
with open("token.txt", "r")as f:
    token = f.read()
print(token)
ku = KiteUtility(token)
# ku.getNwriteNifty50InstrumentToken()
it_df = ku.getInstrumentTokenDF()
startTrade(ku, it_df)

pass


