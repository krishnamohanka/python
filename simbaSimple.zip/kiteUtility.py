import pandas as pd
import requests
import io
import datetime
import time
import logging
import numpy as np
from kiteconnect import KiteConnect


class KiteUtility:
    def __init__(self,accessToken,apiKey='yw8yelu5bpfel8ib'):
        self.kite = KiteConnect(api_key=apiKey)
        self.kite.set_access_token(accessToken)
        self.currentDate = datetime.datetime.now().strftime("%Y-%m-%d")
        self.instrumentDF = None


    def getNwriteNifty50InstrumentToken(self):
        nseList = self.kite.instruments("NSE")
        nseList = pd.DataFrame(nseList, columns=["tradingsymbol", "instrument_token"])
        url = r"https://www.nseindia.com/content/indices/ind_nifty50list.csv"
        r = requests.get(url)
        niftyFiftyList = pd.read_csv(io.StringIO(r.text))
        niftyFiftyList["tradingsymbol"] = niftyFiftyList["Symbol"]
        nifty50_token = nseList.merge(niftyFiftyList, on="tradingsymbol", how="inner")
        nifty50_token["NSEsymbol"] = nifty50_token["tradingsymbol"].apply(lambda x:'NSE:'+str(x))
        d = self.kite.quote(list(nifty50_token["NSEsymbol"]))
        l = []
        for k in d.keys():
            if (int(d[k]["last_price"]) >= 200 and int(d[k]["last_price"]) <= 700):
                print(d[k]["last_price"])
                l.append(k)
        nifty50_token = nifty50_token[nifty50_token["NSEsymbol"].apply(lambda x: True if x in l else False)]
        nifty50_token.to_csv("instrumenttoken.csv")

    def getInstrumentTokenDF(self):
        self.instrumentDF=pd.read_csv("instrumenttoken.csv",usecols=['tradingsymbol','instrument_token'])
        return self.instrumentDF

    def getHistoricalData(self,instrument_token,fromdate=None,todate=None,minute=5):
        fromdate ="2018-05-25" #self.currentDate
        todate = self.currentDate
        data = self.kite.historical_data(instrument_token, str(fromdate), str(todate), str(5)+'minute')
        datadf = pd.DataFrame(data)
        return datadf

    def getInstrumentFromSymabol(self,symbol):
        if self.instrumentDF is not None:
            result = self.instrumentDF.loc[self.instrumentDF["tradingsymbol"] == symbol, "instrument_token"].iloc[0]
            return result

    def getSymbolFromInstrument(self, instrument):
        if (self.instrumentDF is not None ):
            result = self.instrumentDF.loc[self.instrumentDF["instrument_token"] == instrument, "tradingsymbol"].iloc[0]
            return result

    def placeOrder(self,symbol,ltp):
        # Place an order
        ltp = self.roundprice(ltp)
        ltp = ltp+.10

        return
        try:
            order_id = self.kite.place_order(tradingsymbol=symbol,
                                           exchange="NSE",
                                           transaction_type=self.kite.TRANSACTION_TYPE_BUY,
                                           quantity=1,
                                           order_type=self.kite.ORDER_TYPE_SL,
                                           product="MIS",
                                           variety="bo",
                                           squareoff="1",
                                           stoploss="1",
                                           price=ltp,
                                           trigger_price=ltp,
                                           trailing_stoploss="1"
                                           )
            logging.info("Order placed. ID is: {}".format(order_id))
            print(order_id)
            time.sleep(2)
            order_id = 180528001634353
            print(self.kite.order_history(order_id))
            orderStatus = pd.DataFrame(self.kite.order_history(order_id))
            orderStatus.to_csv("orderStatus.csv")
            orders = pd.DataFrame(self.kite.orders())
            orders.to_csv("orders.csv")
            pass

        except Exception as e:
            logging.info("Order placement failed: {}".format(str(e)))
            print("some challenge")

        def roundprice(self, prc):
            lessprice = np.floor(prc)
            flootdiff = int((prc - lessprice) * 100)
            mod5 = flootdiff % 5
            floatplace = flootdiff - mod5
            prc = lessprice + (1 - (1 - (floatplace / 100.0)))
            return prc








